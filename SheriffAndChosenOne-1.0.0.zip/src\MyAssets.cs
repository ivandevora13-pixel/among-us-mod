using MiraAPI.Utilities.Assets;
using UnityEngine;

namespace MyFirstMod;

/// <summary>
/// Sprites and sounds shipped inside the DLL. The string is the embedded resource path.
/// </summary>
public static class MyAssets
{
    public static LoadableResourceAsset ShootButton { get; } =
        new("MyFirstMod.Resources.Buttons.Shoot.png");

    public static LoadableResourceAsset ChosenOneButton { get; } =
        new("MyFirstMod.Resources.Buttons.Crown.png");
}
