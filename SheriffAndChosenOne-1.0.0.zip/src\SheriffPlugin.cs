using BepInEx;
using BepInEx.Configuration;
using BepInEx.Unity.IL2CPP;
using HarmonyLib;
using Il2CppInterop.Runtime.Injection;
using MiraAPI;
using MiraAPI.PluginLoading;
using MiraAPI.Translation;
using MyFirstMod.UI;
using Reactor;
using Reactor.Networking;
using Reactor.Networking.Attributes;

namespace MyFirstMod;

// BepInAutoPlugin generates the [BepInPlugin] attribute (GUID, name, version) for us.
[BepInAutoPlugin("myfirstmod.sheriff", "Sheriff And Chosen One Mod")]
[BepInProcess("Among Us.exe")]
[BepInDependency(ReactorPlugin.Id)]
[BepInDependency(MiraApiPlugin.Id)]
// Every player in the lobby must have this mod installed.
[ReactorModFlags(ModFlags.RequireOnAllClients)]
public partial class SheriffPlugin : BasePlugin, IMiraPlugin
{
    public Harmony Harmony { get; } = new(Id);

    // Shown in the mod settings menu.
    public string OptionsTitleText => "Sheriff & Chosen One";

    public string CustomOptionMenuNameTwo => "Sheriff & Chosen One";

    public ConfigFile GetConfigFile() => Config;

    public override void Load()
    {
        // Loads Resources/Locale/*.xml from this assembly.
        MiraLocaleManager.Register("myfirstmod.sheriff");

        // A MonoBehaviour written in a mod must be injected into the IL2CPP
        // domain before AddComponent<T>() can be used on it.
        ClassInjector.RegisterTypeInIl2Cpp<LobbyRoleListOverlay>();

        // A patch failure must never take the whole mod down: roles and buttons
        // are registered by MiraAPI independently of this call.
        try
        {
            Harmony.PatchAll();
        }
        catch (System.Exception ex)
        {
            Log.LogError($"Harmony patches failed (roles still work): {ex}");
        }

        Log.LogInfo("Sheriff & Chosen One Mod loaded!");
    }
}
