# Sheriff & The Chosen One

A small Among Us mod that adds two roles and a host-only lobby panel.

- **Sheriff** (Crewmate): a **Shoot** ability. Shoot an Impostor and they die. Shoot anyone else and the Sheriff dies instead.
- **The Chosen One** (Impostor): a **Judgment** ability that can kill **any** player, including other Impostors and the Sheriff, at long range. Also keeps the normal kill, vent and sabotage.

Everything is host-configurable in the normal role settings, and the host gets a **LOBBY ROLES** readout in the lobby.

## What's in the box

| Role | Team | Ability | Cooldown |
| --- | --- | --- | --- |
| Sheriff | Crewmate | **Shoot** - kills an Impostor, misfires kill the Sheriff | 25 s (10 s at round start) |
| The Chosen One | Impostor | **Judgment** - kills any player, including Impostors and the Sheriff | 35 s (10 s at round start) |

- The Chosen One is a normal Impostor for win conditions, vents, sabotage and the vanilla kill button.
- Judgment has 9 units of range and a purple outline on the target.
- Both roles appear in **Game Settings → Roles** with an amount and a chance slider.
- The host sees a **LOBBY ROLES** box in the lobby (right side) showing every enabled custom role, its count and its chance. Other players do not see it.

## Requirements

- Among Us **2026.9.29**, 32-bit (x86). Tested with the SteamGG/itch repack; the matching Steam build should also work.
- **BepInEx 6.0.0-be.735** for Unity IL2CPP, **win-x86** (not x64).
- Every player in the lobby must install this mod plus its two dependencies.

Bundled dependencies (already in `BepInEx/plugins`):

- **MiraAPI 0.6.0**
- **Reactor 2.5.0-ci.371** - the copy in this zip is **patched** for the SteamGG/itch build. See the note below.

## Install

1. Install BepInEx 6 be.735 into the folder that contains `Among Us.exe`:
   - Download `BepInEx-Unity.IL2CPP-win-x86-6.0.0-be.735+...zip`.
   - Extract it into the game folder so `winhttp.dll`, `doorstop_config.ini` and the `BepInEx` folder sit next to `Among Us.exe`.
2. Copy the `BepInEx` folder from this zip into the game folder and merge it with the existing one:
   - `BepInEx/plugins/MyFirstMod.dll`
   - `BepInEx/plugins/MiraAPI.dll`
   - `BepInEx/plugins/Reactor.dll`
3. Launch the game once. The first launch after installing BepInEx can take 1-2 minutes while it generates interop assemblies.
4. Open `BepInEx/LogOutput.log` and look for:

   ```
   [Info :Sheriff And Chosen One Mod] Sheriff & Chosen One Mod loaded!
   ```

5. Host a lobby and check **Game Settings → Roles** (last page, "Sheriff & Chosen One").

### Reactor note (important for the SteamGG/itch repack)

The bundled `Reactor.dll` was **byte-patched** to match the compiler-generated class names in the SteamGG 2026.9.29 build. Stock Reactor throws a `TypeLoadException` on that repack.

- **SteamGG/itch repack:** keep the bundled patched `Reactor.dll`.
- **Steam or another build:** if the patched DLL errors, replace `BepInEx/plugins/Reactor.dll` with `extras/Reactor.dll.original` (the unmodified 2.5.0-ci.371 file), or reinstall Reactor from the Reactor installer.

Do not mix the two files: only one `Reactor.dll` may be in `plugins`.

## Configure

1. Host a game and stay in the lobby.
2. Open **Game Settings → Roles** and go to the last page (**Sheriff & Chosen One**).
3. Set the role amounts and chances:
   - Sheriff: `# of role` 1, `% chance` 100 for testing.
   - The Chosen One: `# of role` 1, `% chance` 100 for testing.
4. Make sure the lobby has at least one **Impostor** slot - The Chosen One is an Impostor role and cannot spawn in an all-crew lobby.
5. Recommended for normal play: 1 Sheriff at 50-100%, 1 Chosen One at 50-100%.

The Chosen One's goal is to kill the other Impostor(s) and the Sheriff, then finish the crew. Since Judgment can target Impostors, the host can use it as a "last impostor standing" role.

## Controls

- **Shoot / Judgment:** `R` (MiraAPI's action button key).
- **Normal kill:** `Q`.
- **Vent:** `V`.
- **Sabotage:** `Tab`.

If `R` conflicts with Report, rebind the ability key in MiraAPI's mod settings (**Mira API settings → Keybinds**). The vanilla Report key is unchanged.

## Test alone (Freeplay)

Freeplay uses MiraAPI's role picker:

1. Start **Freeplay**.
2. Open the role picker and choose **Impostor → Sheriff And Chosen One Mod → The Chosen One** (or **Crewmate → ... → Sheriff**).
3. The role is applied immediately and the ability button appears.

## Troubleshooting

- `Assembly MiraAPI.dll is not registered in il2cpp` and `Local settings tab MiraApiSettings already exists` are known MiraAPI log spam and are harmless.
- If the lobby panel does not appear, check `BepInEx/LogOutput.log` for `[MyFirstMod] Lobby role panel failed:` - that line has the real error.
- If a role never spawns: check its chance is above 0%, its count is at least 1, and the lobby has an Impostor slot for The Chosen One.
- If the game crashes or the mod does not load: confirm BepInEx is the **x86** IL2CPP build and that only one `Reactor.dll` is installed.
- All players need the same mod version. The mod is marked `RequireOnAllClients`.
- The game may start its tutorial/freeplay automatically on a fresh account. That is the game, not this mod. Finish or skip the tutorial once, then create a normal lobby.

## Build from source

`src/` contains the complete project.

Requirements: .NET 6 SDK.

1. Open `src/MyFirstMod.csproj` and change `<AmongUs>` to your game folder.
2. Build:

   ```powershell
   cd src
   dotnet build -c Release
   ```

3. The build copies `MyFirstMod.dll` to `BepInEx/plugins` automatically.

Packages come from NuGet and the Reactor/BepInEx feeds configured in `src/nuget.config`:
BepInEx 6.0.0-be.735, Reactor 2.5.0-ci.371, AllOfUs.MiraAPI 0.6.0, AmongUs.GameLibs.Steam 2026.9.29.

Source layout:

```
src/
  SheriffPlugin.cs              plugin entry, locale + Harmony setup
  Roles/SheriffRole.cs          Sheriff role definition
  Roles/ChosenOneRole.cs        The Chosen One role definition
  Buttons/SheriffShootButton.cs Shoot logic and misfire rule
  Buttons/ChosenOneJudgmentButton.cs  Judgment targeting and kill logic
  UI/LobbyRoleListOverlay.cs    host-only lobby panel
  Patches/LobbyStartPatch.cs    creates the panel when a lobby starts
  Resources/Locale/en_US.xml    role and button text
  MyAssets.cs                   embedded button/crown sprites
```

## Credits

- MiraAPI 0.6.0 - All Of Us / Mira team
- Reactor 2.5.0-ci.371 - Nuclear Powered / Reactor team
- BepInEx 6 - BepInEx team
- Among Us - Innersloth

Not affiliated with Innersloth. Play nice: this mod is intended for private lobbies with friends who agreed to install it.
