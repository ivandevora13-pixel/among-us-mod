using HarmonyLib;
using MyFirstMod.UI;

namespace MyFirstMod.Patches;

/// <summary>
/// Creates the host-only role panel as soon as a lobby exists.
/// Patching is safe inside Plugin.Load (no Unity calls there); the postfix runs
/// later, when the engine is fully initialised.
/// </summary>
[HarmonyPatch(typeof(LobbyBehaviour), "Start")]
public static class LobbyStartPatch
{
    [HarmonyPostfix]
    public static void Postfix(LobbyBehaviour __instance)
    {
        LobbyRoleListOverlay.Create(__instance);
    }
}
