using MiraAPI.Hud;
using MiraAPI.Utilities.Assets;
using MyFirstMod.Roles;
using UnityEngine;

namespace MyFirstMod.Buttons;

/// <summary>
/// The Scout's speed burst. HasEffect makes MiraAPI run the effect timer and
/// call OnEffectEnd when the burst is over.
/// </summary>
public class ScoutSprintButton : CustomActionButton
{
    private float _baseSpeed;
    private bool _boosted;

    public override string Name => "button.scout.sprint";

    public override float Cooldown => 20f;

    public override float InitialCooldown => 10f;

    public override LoadableAsset<Sprite> Sprite => MyAssets.ScoutButton;

    public override bool HasEffect => true;

    public override float EffectDuration => 4f;

    public override bool PauseTimerInVent => true;

    public override bool Enabled(RoleBehaviour? role) => role is ScoutRole;

    protected override void OnClick()
    {
        var player = PlayerControl.LocalPlayer;
        if (player == null || player.Data == null || player.Data.IsDead)
        {
            return;
        }

        _baseSpeed = player.MyPhysics.Speed;
        player.MyPhysics.Speed = _baseSpeed * 1.65f;
        _boosted = true;
    }

    public override void OnEffectEnd()
    {
        var player = PlayerControl.LocalPlayer;
        if (_boosted && player != null && player.Data != null && !player.Data.IsDead)
        {
            player.MyPhysics.Speed = _baseSpeed;
        }

        _boosted = false;
    }
}
