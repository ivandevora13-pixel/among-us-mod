using MiraAPI.Events;
using MiraAPI.Events.Vanilla.Gameplay;
using MiraAPI.Utilities;
using MyFirstMod.Roles;
using UnityEngine;

namespace MyFirstMod.Events;

/// <summary>
/// Picks a bounty for the local Bounty Hunter at the start of each round and
/// adjusts the local kill timer when a body drops.
/// </summary>
public static class BountyHunterEvents
{
    private static byte _bountyId = byte.MaxValue;

    public static void Register()
    {
        MiraEventManager.RegisterEventHandler<RoundStartEvent>(OnRoundStart, 0);
        MiraEventManager.RegisterEventHandler<AfterMurderEvent>(OnAfterMurder, 0);
    }

    private static void OnRoundStart(RoundStartEvent e)
    {
        if (PlayerControl.LocalPlayer?.Data?.Role is BountyHunterRole)
        {
            AssignBounty();
        }
    }

    private static void OnAfterMurder(AfterMurderEvent e)
    {
        var local = PlayerControl.LocalPlayer;
        if (local?.Data?.Role is not BountyHunterRole || e.Source == null || e.Source.PlayerId != local.PlayerId)
        {
            return;
        }

        if (e.Target != null && e.Target.PlayerId == _bountyId)
        {
            local.SetKillTimer(2.5f);
            Helpers.CreateAndShowNotification(
                "Bounty claimed! Your kill cooldown is reset.",
                new Color(1f, 0.55f, 0.1f));
            AssignBounty();
        }
        else
        {
            local.SetKillTimer(35f);
            Helpers.CreateAndShowNotification(
                "That was not your bounty. Kill cooldown penalized.",
                new Color(0.9f, 0.3f, 0.3f));
        }
    }

    private static void AssignBounty()
    {
        var local = PlayerControl.LocalPlayer;
        if (local == null || PlayerControl.AllPlayerControls == null)
        {
            return;
        }

        var candidates = new System.Collections.Generic.List<PlayerControl>();
        for (var i = 0; i < PlayerControl.AllPlayerControls.Count; i++)
        {
            var player = PlayerControl.AllPlayerControls[i];
            if (player == null || player.PlayerId == local.PlayerId)
            {
                continue;
            }

            var data = player.Data;
            if (data == null || data.IsDead || data.Role == null || data.Role.IsImpostor)
            {
                continue;
            }

            candidates.Add(player);
        }

        if (candidates.Count == 0)
        {
            _bountyId = byte.MaxValue;
            return;
        }

        var bounty = candidates[UnityEngine.Random.Range(0, candidates.Count)];
        _bountyId = bounty.PlayerId;

        Helpers.CreateAndShowNotification(
            $"Bounty: {bounty.Data.PlayerName}",
            new Color(1f, 0.55f, 0.1f));
    }
}
