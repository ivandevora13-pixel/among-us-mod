using MiraAPI.Events;
using MiraAPI.Events.Vanilla.Gameplay;
using MiraAPI.Utilities;
using MyFirstMod.Roles;
using UnityEngine;

namespace MyFirstMod.Events;

/// <summary>
/// Implements the Medic's one-hit shield. BeforeMurderEvent is cancelable, so
/// the kill never reaches the victim when the shield is ready.
/// </summary>
public static class MedicEvents
{
    private static bool _shieldReady;

    public static void Register()
    {
        MiraEventManager.RegisterEventHandler<RoundStartEvent>(OnRoundStart, 0);
        MiraEventManager.RegisterEventHandler<BeforeMurderEvent>(OnBeforeMurder, 0);
    }

    private static void OnRoundStart(RoundStartEvent e)
    {
        _shieldReady = true;

        if (PlayerControl.LocalPlayer?.Data?.Role is MedicRole)
        {
            Helpers.CreateAndShowNotification(
                "Your shield is ready. It blocks one kill.",
                new Color(0.4f, 0.85f, 1f));
        }
    }

    private static void OnBeforeMurder(BeforeMurderEvent e)
    {
        if (!_shieldReady || e.Target?.Data?.Role is not MedicRole)
        {
            return;
        }

        _shieldReady = false;
        e.Cancel();

        if (e.Target.AmOwner)
        {
            Helpers.CreateAndShowNotification(
                "Your shield absorbed the kill!",
                new Color(0.4f, 0.85f, 1f));
        }
    }
}
