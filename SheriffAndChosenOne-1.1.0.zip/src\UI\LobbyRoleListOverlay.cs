using System.Text;
using Il2CppInterop.Runtime;
using MiraAPI.Roles;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace MyFirstMod.UI;

/// <summary>
/// A small host-only panel in the lobby that lists every custom role that can
/// spawn, how many, and the chance. Built from plain Unity UI so it does not
/// depend on the lobby's own layout.
/// </summary>
public class LobbyRoleListOverlay : MonoBehaviour
{
    private static LobbyBehaviour? _pendingLobby;

    private LobbyBehaviour? _lobby;
    private RectTransform? _background;
    private TextMeshProUGUI? _text;
    private float _refreshTimer;

    /// <summary>Called from the LobbyBehaviour.Start postfix (Unity is fully ready there).</summary>
    public static void Create(LobbyBehaviour lobby)
    {
        if (lobby == null || GameObject.Find("MyFirstMod.LobbyRoleList") != null)
        {
            return;
        }

        try
        {
            // Awake() runs during AddComponent, so pass the lobby through a
            // static field instead of casting the component to its managed type.
            _pendingLobby = lobby;
            var root = new GameObject("MyFirstMod.LobbyRoleList");
            root.AddComponent(Il2CppType.Of<LobbyRoleListOverlay>());
        }
        catch (System.Exception ex)
        {
            // Never let a panel failure break the lobby or the other mod features.
            _pendingLobby = null;
            Debug.LogError($"[MyFirstMod] Lobby role panel failed: {ex}");
        }
    }

    private void Awake()
    {
        _lobby = _pendingLobby;
        _pendingLobby = null;

        var canvas = gameObject.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 100;

        var scaler = gameObject.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920f, 1080f);
        scaler.matchWidthOrHeight = 0.5f;

        var backgroundObject = new GameObject("Background");
        backgroundObject.transform.SetParent(transform, false);

        var image = backgroundObject.AddComponent<Image>();
        image.color = new Color(0f, 0f, 0f, 0.65f);

        _background = image.rectTransform;
        _background.anchorMin = new Vector2(1f, 0.5f);
        _background.anchorMax = new Vector2(1f, 0.5f);
        _background.pivot = new Vector2(1f, 0.5f);
        _background.anchoredPosition = new Vector2(-30f, 40f);
        _background.sizeDelta = new Vector2(400f, 130f);

        var textObject = new GameObject("Text");
        textObject.transform.SetParent(backgroundObject.transform, false);

        _text = textObject.AddComponent<TextMeshProUGUI>();
        _text.fontSize = 24f;
        _text.alignment = TextAlignmentOptions.TopLeft;
        _text.color = Color.white;
        _text.enableWordWrapping = false;
        _text.overflowMode = TextOverflowModes.Overflow;

        var textRect = _text.rectTransform;
        textRect.anchorMin = Vector2.zero;
        textRect.anchorMax = Vector2.one;
        textRect.offsetMin = new Vector2(16f, 12f);
        textRect.offsetMax = new Vector2(-16f, -12f);

        _text.text = "";
    }

    private void Update()
    {
        // The lobby was destroyed (left the lobby or the match started).
        if (_lobby == null)
        {
            Destroy(gameObject);
            return;
        }

        _refreshTimer += Time.deltaTime;
        if (_refreshTimer < 0.5f)
        {
            return;
        }

        _refreshTimer = 0f;

        if (_text == null || _background == null)
        {
            return;
        }

        var client = AmongUsClient.Instance;
        var isHost = client != null && client.AmHost;

        // Hosts only - other players never see this panel.
        if (!isHost)
        {
            _text.text = "";
            _background.gameObject.SetActive(false);
            return;
        }

        _background.gameObject.SetActive(true);
        _text.text = BuildText(out var lineCount);
        _background.sizeDelta = new Vector2(400f, 66f + 34f * lineCount);
    }

    private static string BuildText(out int lineCount)
    {
        var builder = new StringBuilder();
        builder.AppendLine("<b>LOBBY ROLES</b>");
        lineCount = 1;

        var any = false;

        try
        {
            // CustomMiraRoles is every registered custom role, which works in the
            // lobby. (CustomRoleUtils.GetActiveRoles only returns in-game roles.)
            foreach (var customRole in CustomRoleManager.CustomMiraRoles)
            {
                if (customRole == null)
                {
                    continue;
                }

                var count = customRole.GetCount() ?? customRole.Configuration.DefaultRoleCount;
                if (count <= 0)
                {
                    continue;
                }

                var chance = customRole.GetChance() ?? customRole.Configuration.DefaultChance;
                var name = customRole.RoleName;

                builder.AppendLine(
                    $"{name}  <color=#9FE8A0>x{count}</color>  <color=#BBBBBB>{chance}%</color>");
                lineCount++;
                any = true;
            }
        }
        catch (System.Exception)
        {
            any = false;
        }

        if (!any)
        {
            builder.AppendLine("<color=#BBBBBB>No custom roles enabled</color>");
            lineCount++;
        }

        return builder.ToString().TrimEnd();
    }
}
