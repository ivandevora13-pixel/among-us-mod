using MiraAPI.Roles;
using UnityEngine;

namespace MyFirstMod.Roles;

/// <summary>
/// A Crewmate with a much larger vision radius. Handled by TorchLightPatch.
/// </summary>
public class TorchRole : CrewmateRole, ICustomRole
{
    public string IdPart => "Torch";

    public string IdPrefix => "MyFirstMod.Role.Crewmate";

    public Color RoleColor => new(1.00f, 0.65f, 0.15f);

    public ModdedRoleTeams Team => ModdedRoleTeams.Crewmate;

    public CustomRoleConfiguration Configuration => new(this)
    {
        MaxRoleCount = 1,
        DefaultRoleCount = 1,
        DefaultChance = 100,
        CanUseVent = false,
        CanUseSabotage = false,
        CanGetKilled = true,
        ShowInFreeplay = true,
        RoleHintType = RoleHintType.RoleTab,
        Icon = MyAssets.TorchButton,
    };
}
