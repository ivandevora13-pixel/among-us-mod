using System.Collections;
using MiraAPI.Events;
using MiraAPI.Events.Vanilla.Meeting;
using MyFirstMod.Roles;
using Reactor.Utilities;
using UnityEngine;

namespace MyFirstMod.Events;

/// <summary>
/// Detects a Jester being voted out and ends the game. The host sends the
/// end-game RPC so every client finishes at the same time.
/// </summary>
public static class JesterEvents
{
    public static bool JesterWon { get; private set; }

    public static void Register()
    {
        MiraEventManager.RegisterEventHandler<EjectionEvent>(OnEjection, 0);
    }

    private static void OnEjection(EjectionEvent e)
    {
        var exiled = e.ExileController?.initData?.networkedPlayer;
        if (exiled?.Role is not JesterRole)
        {
            return;
        }

        JesterWon = true;

        if (AmongUsClient.Instance != null && AmongUsClient.Instance.AmHost && GameManager.Instance != null)
        {
            Coroutines.Start(EndGameSoon());
        }
    }

    private static IEnumerator EndGameSoon()
    {
        // Let the ejection animation finish before showing the victory screen.
        yield return new WaitForSeconds(3f);

        if (GameManager.Instance != null)
        {
            GameManager.Instance.RpcEndGame(GameOverReason.CrewmatesByVote, false);
        }
    }
}
