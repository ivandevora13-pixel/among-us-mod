using MiraAPI.Events;
using MiraAPI.Events.Vanilla.Gameplay;
using MiraAPI.Events.Vanilla.Player;
using MiraAPI.Utilities;
using MyFirstMod.Roles;
using UnityEngine;

namespace MyFirstMod.Events;

/// <summary>
/// Tracks whether the local Snitch has finished every task. The actual name
/// coloring is done by SnitchNamePatch.
/// </summary>
public static class SnitchEvents
{
    public static bool Revealed { get; private set; }

    public static void Register()
    {
        MiraEventManager.RegisterEventHandler<RoundStartEvent>(OnRoundStart, 0);
        MiraEventManager.RegisterEventHandler<CompleteTaskEvent>(OnTaskComplete, 0);
    }

    private static void OnRoundStart(RoundStartEvent e)
    {
        Refresh();
    }

    private static void OnTaskComplete(CompleteTaskEvent e)
    {
        if (e.Player == null || PlayerControl.LocalPlayer == null ||
            e.Player.PlayerId != PlayerControl.LocalPlayer.PlayerId)
        {
            return;
        }

        Refresh();
    }

    private static void Refresh()
    {
        var local = PlayerControl.LocalPlayer;
        if (local?.Data?.Role is not SnitchRole)
        {
            Revealed = false;
            return;
        }

        var tasks = local.Data.Tasks;
        if (tasks == null)
        {
            return;
        }

        var allDone = true;
        for (var i = 0; i < tasks.Count; i++)
        {
            if (!tasks[i].Complete)
            {
                allDone = false;
                break;
            }
        }

        if (!allDone)
        {
            Revealed = false;
            return;
        }

        if (Revealed)
        {
            return;
        }

        Revealed = true;
        Helpers.CreateAndShowNotification(
            "All tasks complete - the Impostors are revealed!",
            new Color(0.95f, 0.4f, 0.7f));
    }
}
