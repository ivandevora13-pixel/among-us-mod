using MiraAPI.Roles;
using UnityEngine;

namespace MyFirstMod.Roles;

/// <summary>
/// A Crewmate who sees the Impostors' names in red once every task is done.
/// </summary>
public class SnitchRole : CrewmateRole, ICustomRole
{
    public string IdPart => "Snitch";

    public string IdPrefix => "MyFirstMod.Role.Crewmate";

    public Color RoleColor => new(0.95f, 0.40f, 0.70f);

    public ModdedRoleTeams Team => ModdedRoleTeams.Crewmate;

    public CustomRoleConfiguration Configuration => new(this)
    {
        MaxRoleCount = 1,
        DefaultRoleCount = 1,
        DefaultChance = 100,
        CanUseVent = false,
        CanUseSabotage = false,
        CanGetKilled = true,
        ShowInFreeplay = true,
        RoleHintType = RoleHintType.RoleTab,
        Icon = MyAssets.SnitchButton,
    };
}
