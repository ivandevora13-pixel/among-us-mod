using AmongUs.GameOptions;
using MiraAPI.Roles;
using UnityEngine;

namespace MyFirstMod.Roles;

/// <summary>
/// A Crewmate who can shoot Impostors. Shooting a Crewmate kills the Sheriff instead.
/// MiraAPI discovers this class automatically - no manual registration needed.
/// </summary>
public class SheriffRole : CrewmateRole, ICustomRole
{
    // Together with IdPrefix this builds the translation keys, e.g.
    // "MyFirstMod.Role.Crewmate.Sheriff" (see Resources/Locale/en_US.xml).
    public string IdPart => "Sheriff";

    public string IdPrefix => "MyFirstMod.Role.Crewmate";

    public Color RoleColor => new(0.85f, 0.65f, 0.13f);

    public ModdedRoleTeams Team => ModdedRoleTeams.Crewmate;

    public CustomRoleConfiguration Configuration => new(this)
    {
        // 1 = only one Sheriff per game at most.
        MaxRoleCount = 1,
        DefaultRoleCount = 1,
        DefaultChance = 100,

        // Sheriffs do not vent, sabotage, or use the vanilla kill button.
        CanUseVent = false,
        CanUseSabotage = false,
        CanGetKilled = true,
    };
}
