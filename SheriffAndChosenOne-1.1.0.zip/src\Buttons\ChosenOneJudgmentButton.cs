using MiraAPI.Hud;
using MiraAPI.Networking;
using MiraAPI.Utilities;
using MiraAPI.Utilities.Assets;
using MyFirstMod.Roles;
using UnityEngine;

namespace MyFirstMod.Buttons;

/// <summary>
/// The Chosen One's "Judgment" ability.
/// Unlike the normal Impostor kill it accepts EVERY player as a target,
/// including other Impostors and the Sheriff.
/// </summary>
public class ChosenOneJudgmentButton : CustomActionButton<PlayerControl>
{
    public override string Name => "button.chosenone.judgment";

    // Long cooldown: this is a finisher, not a second normal kill.
    public override float Cooldown => 35f;

    public override float InitialCooldown => 10f;

    // Long reach, so the Chosen One can strike across most of a room.
    public override float Distance => 9f;

    public override LoadableAsset<Sprite> Sprite => MyAssets.ChosenOneButton;

    public override bool PauseTimerInVent => true;

    public override bool Enabled(RoleBehaviour? role) => role is ChosenOneRole;

    public override PlayerControl? GetTarget()
    {
        // "true" lets us target Impostors too - the normal kill button cannot do this.
        return PlayerControl.LocalPlayer.GetClosestPlayer(
            true,
            Distance,
            predicate: player =>
                player != null &&
                player != PlayerControl.LocalPlayer &&
                player.Data != null &&
                !player.Data.IsDead &&
                !player.Data.Disconnected);
    }

    public override void SetOutline(bool active)
    {
        Target?.cosmetics.SetOutline(
            active,
            new Il2CppSystem.Nullable<Color>(new Color(0.72f, 0.4f, 1f)));
    }

    public override bool IsTargetValid(PlayerControl? target)
    {
        return target != null && target.Data != null && !target.Data.IsDead;
    }

    protected override void OnClick()
    {
        var chosenOne = PlayerControl.LocalPlayer;
        var target = Target;

        if (target == null || target.Data == null || target.Data.IsDead)
        {
            return;
        }

        // Networked kill confirmed by the host - works on any role.
        chosenOne.RpcCustomMurder(target, MeetingCheck.OutsideMeeting);

        var targetRole = target.Data.Role;
        if (targetRole is SheriffRole)
        {
            Helpers.CreateAndShowNotification(
                "The Sheriff has fallen to your Judgment.",
                new Color(0.85f, 0.75f, 0.2f));
        }
        else if (targetRole != null && targetRole.IsImpostor)
        {
            Helpers.CreateAndShowNotification(
                "A rival Impostor eliminated. You alone are chosen.",
                new Color(1f, 0.35f, 0.35f));
        }
        else
        {
            Helpers.CreateAndShowNotification(
                "Judgment delivered.",
                new Color(0.72f, 0.4f, 1f));
        }
    }
}
