using MiraAPI.Utilities.Assets;
using UnityEngine;

namespace MyFirstMod;

/// <summary>
/// Sprites and sounds shipped inside the DLL. The string is the embedded resource path.
/// </summary>
public static class MyAssets
{
    public static LoadableResourceAsset ShootButton { get; } =
        new("MyFirstMod.Resources.Buttons.Shoot.png");

    public static LoadableResourceAsset ChosenOneButton { get; } =
        new("MyFirstMod.Resources.Buttons.Crown.png");

    public static LoadableResourceAsset ScoutButton { get; } =
        new("MyFirstMod.Resources.Buttons.Scout.png");

    public static LoadableResourceAsset MedicButton { get; } =
        new("MyFirstMod.Resources.Buttons.Medic.png");

    public static LoadableResourceAsset DetectiveButton { get; } =
        new("MyFirstMod.Resources.Buttons.Detective.png");

    public static LoadableResourceAsset SnitchButton { get; } =
        new("MyFirstMod.Resources.Buttons.Snitch.png");

    public static LoadableResourceAsset TorchButton { get; } =
        new("MyFirstMod.Resources.Buttons.Torch.png");

    public static LoadableResourceAsset BountyHunterButton { get; } =
        new("MyFirstMod.Resources.Buttons.BountyHunter.png");

    public static LoadableResourceAsset JesterButton { get; } =
        new("MyFirstMod.Resources.Buttons.Jester.png");
}
