using HarmonyLib;
using MyFirstMod.Events;
using MyFirstMod.Roles;
using UnityEngine;

namespace MyFirstMod.Patches;

/// <summary>
/// Once the local Snitch has finished all tasks, paint Impostor names red.
/// Running as a postfix on each PlayerControl.Update keeps the color applied
/// after the game's own name-color logic runs.
/// </summary>
[HarmonyPatch(typeof(PlayerControl), nameof(PlayerControl.FixedUpdate))]
public static class SnitchNamePatch
{
    public static void Postfix(PlayerControl __instance)
    {
        if (!SnitchEvents.Revealed)
        {
            return;
        }

        var local = PlayerControl.LocalPlayer;
        if (local?.Data?.Role is not SnitchRole)
        {
            return;
        }

        var data = __instance.Data;
        if (data?.Role == null || !data.Role.IsImpostor || __instance.cosmetics == null)
        {
            return;
        }

        __instance.cosmetics.SetNameColor(Color.red);
    }
}
