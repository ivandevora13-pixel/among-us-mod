using MiraAPI.Hud;
using MiraAPI.Utilities;
using MiraAPI.Utilities.Assets;
using MyFirstMod.Roles;
using UnityEngine;

namespace MyFirstMod.Buttons;

/// <summary>
/// The Detective's investigation. It only sends a notification to the
/// Detective, telling them which room the target is standing in.
/// </summary>
public class DetectiveInvestigateButton : CustomActionButton<PlayerControl>
{
    public override string Name => "button.detective.investigate";

    public override float Cooldown => 20f;

    public override float InitialCooldown => 10f;

    public override float Distance => 9f;

    public override LoadableAsset<Sprite> Sprite => MyAssets.DetectiveButton;

    public override bool PauseTimerInVent => true;

    public override bool Enabled(RoleBehaviour? role) => role is DetectiveRole;

    public override PlayerControl? GetTarget()
    {
        return PlayerControl.LocalPlayer.GetClosestPlayer(
            true,
            Distance,
            predicate: player =>
                player != null &&
                player != PlayerControl.LocalPlayer &&
                player.Data != null &&
                !player.Data.IsDead &&
                !player.Data.Disconnected);
    }

    public override void SetOutline(bool active)
    {
        Target?.cosmetics.SetOutline(
            active,
            new Il2CppSystem.Nullable<Color>(new Color(0.35f, 0.7f, 1f)));
    }

    public override bool IsTargetValid(PlayerControl? target)
    {
        return target != null && target.Data != null && !target.Data.IsDead;
    }

    protected override void OnClick()
    {
        var target = Target;
        if (target == null || target.Data == null)
        {
            return;
        }

        var room = Helpers.GetRoom(target.transform.position);
        var roomName = room != null ? room.RoomId.ToString() : "a hallway";

        Helpers.CreateAndShowNotification(
            $"{target.Data.PlayerName} is in {roomName}.",
            new Color(0.35f, 0.7f, 1f));
    }
}
