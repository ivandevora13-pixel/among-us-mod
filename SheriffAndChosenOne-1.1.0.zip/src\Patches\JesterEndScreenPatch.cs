using HarmonyLib;
using MyFirstMod.Events;
using UnityEngine;

namespace MyFirstMod.Patches;

/// <summary>
/// Replaces the normal end-game headline when the Jester was voted out.
/// </summary>
[HarmonyPatch(typeof(EndGameManager), nameof(EndGameManager.SetEverythingUp))]
public static class JesterEndScreenPatch
{
    public static void Postfix(EndGameManager __instance)
    {
        if (!JesterEvents.JesterWon)
        {
            return;
        }

        if (__instance.WinText != null)
        {
            __instance.WinText.text = "The Jester wins!";
            __instance.WinText.color = new Color(0.8f, 0.3f, 1f);
        }
    }
}
