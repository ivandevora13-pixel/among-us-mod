# Sheriff & The Chosen One (9-role pack)

An Among Us mod with nine roles, host-configurable role settings, and a host-only **LOBBY ROLES** readout.

| Role | Team | Ability |
| --- | --- | --- |
| **Sheriff** | Crewmate | **Shoot** (R, 25 s): kill an Impostor. A misfire kills the Sheriff. |
| **Scout** | Crewmate | **Sprint** (R, 20 s): 65% faster for 4 s. |
| **Medic** | Crewmate | Passive shield: the first kill against you each round is blocked. |
| **Detective** | Crewmate | **Investigate** (R, 20 s): learn which room a nearby player is in. |
| **Snitch** | Crewmate | Passive: when all your tasks are done, Impostor names turn red. |
| **Torch** | Crewmate | Passive: much larger vision radius. |
| **The Chosen One** | Impostor | **Judgment** (R, 35 s): kill ANY player, including other Impostors and the Sheriff. Keeps normal kill/vent/sabotage. |
| **Bounty Hunter** | Impostor | Passive bounty each round. Kill the bounty to reset your kill cooldown; killing anyone else sets it to 35 s. |
| **Jester** | Neutral | Passive: win by getting voted out. Jester tasks do not count toward the crew task bar. |

The host sees a **LOBBY ROLES** box on the right side of the lobby listing every enabled custom role, its count and its chance. Only the host sees it.

## Requirements

- Among Us **2026.9.29**, 32-bit (x86). Tested with the SteamGG/itch repack; the matching Steam build should work too.
- **BepInEx 6.0.0-be.735** IL2CPP, **win-x86**.
- Every player in the lobby needs this mod and its dependencies.

Bundled dependencies (in `BepInEx/plugins`):

- **MiraAPI 0.6.0**
- **Reactor 2.5.0-ci.371** — patched for the SteamGG/itch build; see the note below.

## Install

1. Install BepInEx 6 be.735 into the folder containing `Among Us.exe` (`winhttp.dll`, `doorstop_config.ini`, `BepInEx/` next to the exe).
2. Extract this zip into the game folder and merge the `BepInEx` folder.
3. Launch once. The first IL2CPP start can take 1-2 minutes.
4. Check `BepInEx/LogOutput.log` for:
   ```
   [Info :Sheriff And Chosen One Mod] Sheriff & Chosen One Mod loaded!
   ```
5. Host a lobby and open **Game Settings → Roles**. The custom roles are on the last pages.

### Reactor note (SteamGG/itch repack)

The bundled `Reactor.dll` is byte-patched for the SteamGG 2026.9.29 build. Stock Reactor throws a `TypeLoadException` on that repack.

- **SteamGG/itch repack:** keep the bundled `Reactor.dll`.
- **Steam or another build:** if Reactor errors, replace `BepInEx/plugins/Reactor.dll` with `extras/Reactor.dll.original` (unmodified 2.5.0-ci.371).

Only one `Reactor.dll` may be in `plugins`.

## Configure

1. Host a game and stay in the lobby.
2. Open **Game Settings → Roles** and go through the last pages.
3. Set the amount and chance for each role you want. Set chance to 100% for testing.
4. The lobby needs at least one **Impostor** slot for The Chosen One and Bounty Hunter.
5. Recommended first test: Sheriff 1 (100%), The Chosen One 1 (100%), all others 0. Then add roles one at a time.

## Controls

- **Role ability:** `R` (MiraAPI action button).
- **Normal kill:** `Q`.
- **Vent:** `V`.
- **Sabotage:** `Tab`.
- Passive roles (Medic, Snitch, Torch, Jester) have no button.

If `R` conflicts with Report, rebind it in **Mira API settings → Keybinds**.

## Test alone (Freeplay)

Start Freeplay, open the role picker, and pick a role under **Crewmate**, **Impostor**, or the neutral folder:

**Impostor → Sheriff And Chosen One Mod → The Chosen One**  
**Crewmate → Sheriff And Chosen One Mod → Scout** (and so on).

The role is applied immediately and its button appears.

## Troubleshooting

- `Assembly MiraAPI.dll is not registered in il2cpp`, `Local settings tab MiraApiSettings already exists`, and `HudManager.Update` NullReferenceException lines are known MiraAPI/repack log noise on this build and do not stop the mod.
- No lobby panel? Look for `[MyFirstMod] Lobby role panel failed:` in the log.
- A role never spawns: check its chance is above 0%, its count is at least 1, and there is an Impostor slot for Impostor roles.
- All players must use the same mod version (`RequireOnAllClients`).
- If the game starts the tutorial/freeplay automatically on a fresh account, that is the game, not this mod.

## Role details

- **Medic:** the shield refreshes at the start of every round. It blocks one murder, including Judgment.
- **Snitch:** the red names are client-side. Other players do not see them. Share your information carefully.
- **Torch:** the larger light also helps during lights sabotage.
- **Bounty Hunter:** the bounty is shown as a notification at round start and after each claim. A wrong kill sets the kill timer to 35 s.
- **Jester:** the game ends when the Jester is ejected, with a custom "The Jester wins!" screen.

## Build from source

`src/` contains the full project.

1. Edit `<AmongUs>` in `src/MyFirstMod.csproj` to your game folder.
2. Run:
   ```powershell
   cd src
   dotnet build -c Release
   ```
3. The DLL is copied to `BepInEx/plugins` automatically.

Packages: BepInEx 6.0.0-be.735, Reactor 2.5.0-ci.371, AllOfUs.MiraAPI 0.6.0, AmongUs.GameLibs.Steam 2026.9.29.

## Credits

- MiraAPI 0.6.0 — All Of Us / Mira team
- Reactor 2.5.0-ci.371 — Nuclear Powered / Reactor team
- BepInEx 6 — BepInEx team
- Among Us — Innersloth

Not affiliated with Innersloth. For private lobbies with friends who agreed to install it.
