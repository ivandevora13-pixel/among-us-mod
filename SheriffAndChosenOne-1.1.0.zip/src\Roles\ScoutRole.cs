using MiraAPI.Roles;
using UnityEngine;

namespace MyFirstMod.Roles;

/// <summary>
/// A Crewmate with a short speed burst. MiraAPI discovers custom roles
/// automatically, so there is no registration call for this class.
/// </summary>
public class ScoutRole : CrewmateRole, ICustomRole
{
    public string IdPart => "Scout";

    public string IdPrefix => "MyFirstMod.Role.Crewmate";

    public Color RoleColor => new(0.20f, 0.85f, 0.55f);

    public ModdedRoleTeams Team => ModdedRoleTeams.Crewmate;

    public CustomRoleConfiguration Configuration => new(this)
    {
        MaxRoleCount = 1,
        DefaultRoleCount = 1,
        DefaultChance = 100,
        CanUseVent = false,
        CanUseSabotage = false,
        CanGetKilled = true,
        ShowInFreeplay = true,
        RoleHintType = RoleHintType.RoleTab,
        Icon = MyAssets.ScoutButton,
    };
}
