using MiraAPI.Roles;
using UnityEngine;

namespace MyFirstMod.Roles;

/// <summary>
/// A Crewmate who survives the first kill of every round. The shield is
/// consumed on the first murder attempt and refreshes when a new round starts.
/// </summary>
public class MedicRole : CrewmateRole, ICustomRole
{
    public string IdPart => "Medic";

    public string IdPrefix => "MyFirstMod.Role.Crewmate";

    public Color RoleColor => new(0.90f, 0.35f, 0.35f);

    public ModdedRoleTeams Team => ModdedRoleTeams.Crewmate;

    public CustomRoleConfiguration Configuration => new(this)
    {
        MaxRoleCount = 1,
        DefaultRoleCount = 1,
        DefaultChance = 100,
        CanUseVent = false,
        CanUseSabotage = false,
        CanGetKilled = true,
        ShowInFreeplay = true,
        RoleHintType = RoleHintType.RoleTab,
        Icon = MyAssets.MedicButton,
    };
}
