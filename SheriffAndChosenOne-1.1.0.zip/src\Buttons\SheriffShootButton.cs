using MiraAPI.Hud;
using MiraAPI.Networking;
using MiraAPI.Utilities;
using MiraAPI.Utilities.Assets;
using MyFirstMod.Roles;
using UnityEngine;

namespace MyFirstMod.Buttons;

/// <summary>
/// The Sheriff's "Shoot" ability. MiraAPI finds this class automatically.
/// </summary>
public class SheriffShootButton : CustomActionButton<PlayerControl>
{
    public override string Name => "button.sheriff.shoot";

    public override float Cooldown => 25f;

    public override float InitialCooldown => 10f;

    public override LoadableAsset<Sprite> Sprite => MyAssets.ShootButton;

    public override bool PauseTimerInVent => true;

    // Only show the button when the local player is the Sheriff.
    public override bool Enabled(RoleBehaviour? role) => role is SheriffRole;

    // Called every frame by MiraAPI; returns the player under the cursor / nearest to us.
    public override PlayerControl? GetTarget()
    {
        return PlayerControl.LocalPlayer.GetClosestPlayer(
            true,
            Distance,
            predicate: player =>
                player != null &&
                player != PlayerControl.LocalPlayer &&
                player.Data != null &&
                !player.Data.IsDead &&
                !player.Data.Disconnected);
    }

    public override void SetOutline(bool active)
    {
        Target?.cosmetics.SetOutline(
            active,
            new Il2CppSystem.Nullable<Color>(new Color(0.95f, 0.75f, 0.2f)));
    }

    public override bool IsTargetValid(PlayerControl? target)
    {
        return target != null && target.Data != null && !target.Data.IsDead;
    }

    protected override void OnClick()
    {
        var sheriff = PlayerControl.LocalPlayer;
        var target = Target;

        if (target == null || target.Data == null || target.Data.IsDead)
        {
            return;
        }

        if (target.Data.Role.IsImpostor)
        {
            // Networked kill, confirmed by the host (prevents desyncs/cheating).
            sheriff.RpcCustomMurder(target, MeetingCheck.OutsideMeeting);
            Helpers.CreateAndShowNotification("You shot an Impostor!", new Color(0.35f, 0.9f, 0.4f));
        }
        else
        {
            // Misfire: the Sheriff dies instead. Classic Sheriff rule.
            Helpers.CreateAndShowNotification("You shot a Crewmate...", new Color(1f, 0.3f, 0.3f));
            sheriff.RpcCustomMurder(
                sheriff,
                MeetingCheck.OutsideMeeting,
                showKillAnim: false,
                teleportMurderer: false);
        }
    }
}
