using MiraAPI.Roles;
using UnityEngine;

namespace MyFirstMod.Roles;

/// <summary>
/// A Crewmate who can learn which room another player is currently in.
/// </summary>
public class DetectiveRole : CrewmateRole, ICustomRole
{
    public string IdPart => "Detective";

    public string IdPrefix => "MyFirstMod.Role.Crewmate";

    public Color RoleColor => new(0.30f, 0.60f, 1.00f);

    public ModdedRoleTeams Team => ModdedRoleTeams.Crewmate;

    public CustomRoleConfiguration Configuration => new(this)
    {
        MaxRoleCount = 1,
        DefaultRoleCount = 1,
        DefaultChance = 100,
        CanUseVent = false,
        CanUseSabotage = false,
        CanGetKilled = true,
        ShowInFreeplay = true,
        RoleHintType = RoleHintType.RoleTab,
        Icon = MyAssets.DetectiveButton,
    };
}
