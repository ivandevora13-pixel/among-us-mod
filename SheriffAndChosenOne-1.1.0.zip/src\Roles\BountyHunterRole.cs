using MiraAPI.Roles;
using UnityEngine;

namespace MyFirstMod.Roles;

/// <summary>
/// An Impostor who receives one random Crewmate as a bounty each round.
/// Killing the bounty resets the kill cooldown; anyone else is a penalty.
/// </summary>
public class BountyHunterRole : ImpostorRole, ICustomRole
{
    public string IdPart => "BountyHunter";

    public string IdPrefix => "MyFirstMod.Role.Impostor";

    public Color RoleColor => new(0.95f, 0.45f, 0.10f);

    public ModdedRoleTeams Team => ModdedRoleTeams.Impostor;

    public CustomRoleConfiguration Configuration => new(this)
    {
        MaxRoleCount = 1,
        DefaultRoleCount = 1,
        DefaultChance = 100,
        CanUseVent = true,
        CanUseSabotage = true,
        CanGetKilled = true,
        UseVanillaKillButton = true,
        ShowInFreeplay = true,
        RoleHintType = RoleHintType.RoleTab,
        Icon = MyAssets.BountyHunterButton,
    };
}
