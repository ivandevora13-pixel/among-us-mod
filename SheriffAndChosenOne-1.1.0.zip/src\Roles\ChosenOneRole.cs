using AmongUs.GameOptions;
using MiraAPI.Roles;
using UnityEngine;

namespace MyFirstMod.Roles;

/// <summary>
/// An Impostor who answers to nobody. The Chosen One can kill ANY player -
/// including other Impostors and the Sheriff - and is expected to remove both
/// before finishing off the crew.
/// </summary>
public class ChosenOneRole : ImpostorRole, ICustomRole
{
    public string IdPart => "ChosenOne";

    public string IdPrefix => "MyFirstMod.Role.Impostor";

    public Color RoleColor => new(0.55f, 0.2f, 0.75f);

    public ModdedRoleTeams Team => ModdedRoleTeams.Impostor;

    public CustomRoleConfiguration Configuration => new(this)
    {
        // At most one Chosen One per game.
        MaxRoleCount = 1,
        DefaultRoleCount = 1,
        DefaultChance = 100,

        // A real Impostor: vents, sabotages, and keeps the normal kill button.
        CanUseVent = true,
        CanUseSabotage = true,
        CanGetKilled = true,
        UseVanillaKillButton = true,

        // Shows up in the freeplay role picker so the role can be tested alone.
        ShowInFreeplay = true,
        RoleHintType = RoleHintType.RoleTab,
        Icon = MyAssets.ChosenOneButton,
    };
}
