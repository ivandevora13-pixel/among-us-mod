using HarmonyLib;
using MyFirstMod.Roles;

namespace MyFirstMod.Patches;

/// <summary>
/// Keeps the Torch's light radius above the normal value. The check prevents
/// calling SetViewDistance every frame once the boost is already applied.
/// </summary>
[HarmonyPatch(typeof(LightSource), nameof(LightSource.Update))]
public static class TorchLightPatch
{
    private const float TorchViewDistance = 9f;

    public static void Postfix(LightSource __instance)
    {
        var local = PlayerControl.LocalPlayer;
        if (local?.Data?.Role is not TorchRole || local.lightSource != __instance)
        {
            return;
        }

        if (__instance.viewDistance < TorchViewDistance)
        {
            __instance.SetViewDistance(TorchViewDistance);
        }
    }
}
