using MiraAPI.Roles;
using UnityEngine;

namespace MyFirstMod.Roles;

/// <summary>
/// A neutral role. The Jester has no kill and wins only if the lobby
/// votes them out; JesterEvents ends the game when that happens.
/// </summary>
public class JesterRole : CrewmateRole, ICustomRole
{
    public string IdPart => "Jester";

    public string IdPrefix => "MyFirstMod.Role.Neutral";

    public Color RoleColor => new(0.75f, 0.30f, 0.95f);

    public ModdedRoleTeams Team => ModdedRoleTeams.Custom;

    public CustomRoleConfiguration Configuration => new(this)
    {
        MaxRoleCount = 1,
        DefaultRoleCount = 1,
        DefaultChance = 100,
        CanUseVent = false,
        CanUseSabotage = false,
        CanGetKilled = true,
        UseVanillaKillButton = false,

        // Jester tasks are a disguise, not real crew progress.
        TasksCountForProgress = false,
        ShowInFreeplay = true,
        RoleHintType = RoleHintType.RoleTab,
        Icon = MyAssets.JesterButton,
    };
}
